#ifndef _NETDB_H_
#define _NETDB_H_

#define NETDB_INTERNAL  -1      /* see errno */
#define MAXHOSTNAMELEN 256

#endif