int yp_get_default_domain(char **domain) {
	return 0;
}

int yp_match(char *domain, char *hosts, char *host, int hostlen, char **value, int *valuelen) {
	return 0;
}
